General Takeuchi Information Criterion(GTIC)


